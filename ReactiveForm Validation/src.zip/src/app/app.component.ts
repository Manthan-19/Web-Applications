import { Component, OnInit } from '@angular/core';

import { FormControl, FormGroup ,FormBuilder,Validators} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
}) 
export class AppComponent implements OnInit
{
  selectedState : string = "";
  constructor(public fbobj : FormBuilder)
  {
  }

  states : any=[];
  selectedValue:any;

  ngOnInit(): void 
  {
    this.states =  [
      {Id : "Maharashtra", Name:"Maharashtra"},
      {Id : "Gujarat", Name:"Gujarat"},
      {Id : "Uttar Pradesh", Name:"Uttar Pradesh"}
    ];
  }

  MarvellousForm = this.fbobj.group
  ({
    firstname : ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      lastname : ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      email : ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"), Validators.minLength(2)]],
      phone : ['', [ Validators.required,
        Validators.pattern("^[0-9]*$"),
        Validators.minLength(10), Validators.maxLength(10)]],
      city : ['', [Validators.required, Validators.minLength(4), , Validators.pattern("^[a-zA-Z]+$")]],
      state : ['', Validators.required],
      ZIPCode : ['', [Validators.required, Validators.minLength(5)]],
      Comments : ['', [Validators.required, Validators.minLength(30)]],
  })
}
