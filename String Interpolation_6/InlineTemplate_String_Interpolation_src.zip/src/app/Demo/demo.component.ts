import { Component } from "@angular/core";

@Component({
    selector:"app-demo-component",
    template:'<h1>Marvellous Infosystems</h1>',
    styles:[
        'h1 {color : blue;}'
    ]
})
export class DemoComponent{} 