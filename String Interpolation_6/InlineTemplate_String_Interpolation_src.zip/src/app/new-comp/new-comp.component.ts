import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent {

  public Name = "Marvellous";

  public Concat(data : string) : string
  {
    var result : string = this.Name + " " + data;
    return result;
  }
}
