import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html',
  styleUrls: ['./marvellous.component.css']
})
export class MarvellousComponent
{
  public MyColor = "Orange";
  public Veg = false;

  public Fun()
  {
    this.Veg = true;
  }

  public Gun()
  {
    this.MyColor = "Blue";
  }
}
